package com.example.freezerauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Freezer Frenzy automation prototype v0.3.
 *
 * - Learns the foreground game package automatically.
 * - Uses Accessibility screenshots to steer left/right.
 * - Detects the large red biohazard obstacle and moves away from it.
 * - Uses colorful-object density as a soft collection target.
 * - Detects the post-round UI through accessibility text when available.
 * - If Play Store opens from an ad, only presses Back to return to the game.
 *
 * IMPORTANT: this service deliberately does not click ads or reward-watch
 * buttons. It may continue to a clearly labelled Next Round control after
 * the round is over when that control is exposed by the game UI.
 */
class AutoAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var running = true
    private var gamePackage: String? = null
    private var lastPackage: String? = null
    private var lastTargetX = -1f
    private var lastSwipeAt = 0L
    private var screenshotBusy = false
    private var lastUiActionAt = 0L

    private val playTop = 0.06f
    private val playBottom = 0.76f

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
        handler.post(loop)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        lastPackage = pkg

        if (pkg == "com.android.vending") {
            // Return from a Play Store redirect. Never tap an ad/store listing.
            handler.postDelayed({ if (lastPackage == "com.android.vending") performGlobalAction(GLOBAL_ACTION_BACK) }, 250)
            return
        }

        if (pkg == packageName) return

        if (!isLikelySystemPackage(pkg) && gamePackage == null) {
            gamePackage = pkg
        }

        if (pkg == gamePackage) {
            handleGameUi(rootInActiveWindow)
        }
    }

    override fun onInterrupt() {
        running = false
        handler.removeCallbacksAndMessages(null)
        executor.shutdownNow()
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            if (lastPackage == gamePackage) {
                handleGameUi(rootInActiveWindow)
                if (Build.VERSION.SDK_INT >= 30 && !screenshotBusy) captureAndDecide()
            }
            handler.postDelayed(this, 220)
        }
    }

    /** Handle only the non-ad, clearly game-owned post-round controls. */
    private fun handleGameUi(root: AccessibilityNodeInfo?) {
        if (root == null) return
        val now = System.currentTimeMillis()
        if (now - lastUiActionAt < 1200) return

        val texts = collectTexts(root)
        val joined = texts.joinToString(" | ").lowercase()

        // The screenshot supplied by the user shows KEEP PLAYING? / SPACE LEFT.
        // After the timer, the game exposes a Next Round control. We only use
        // that control; we do not press WATCH/3X because that starts an ad.
        if (joined.contains("next round")) {
            val node = findTextNode(root, "next round")
            if (node != null && node.isClickable) {
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                lastUiActionAt = now
                lastTargetX = -1f
                return
            }
            // Some games make the parent clickable rather than the text node.
            val parent = node?.parent
            if (parent?.isClickable == true) {
                parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                lastUiActionAt = now
                lastTargetX = -1f
            }
        }
    }

    private fun collectTexts(root: AccessibilityNodeInfo): List<String> {
        val out = ArrayList<String>()
        fun walk(n: AccessibilityNodeInfo) {
            n.text?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
            n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        return out
    }

    private fun findTextNode(root: AccessibilityNodeInfo, wanted: String): AccessibilityNodeInfo? {
        val target = wanted.lowercase()
        fun walk(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            val t = n.text?.toString()?.lowercase()
            val d = n.contentDescription?.toString()?.lowercase()
            if ((t != null && t.contains(target)) || (d != null && d.contains(target))) return n
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                val found = walk(c)
                if (found != null) return found
            }
            return null
        }
        return walk(root)
    }

    private fun captureAndDecide() {
        screenshotBusy = true
        takeScreenshot(
            android.view.Display.DEFAULT_DISPLAY,
            executor,
            object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    try {
                        val hardware = result.hardwareBuffer ?: throw IllegalStateException()
                        val bitmap = Bitmap.wrapHardwareBuffer(hardware, result.colorSpace)
                        hardware.close()
                        if (bitmap != null) {
                            val copy = bitmap.copy(Bitmap.Config.ARGB_8888, false)
                            bitmap.recycle()
                            executor.execute {
                                val decision = analyze(copy)
                                copy.recycle()
                                handler.post {
                                    screenshotBusy = false
                                    if (lastPackage == gamePackage && decision != null) applyDecision(decision)
                                }
                            }
                            return
                        }
                    } catch (_: Throwable) { }
                    handler.post { screenshotBusy = false }
                }
                override fun onFailure(errorCode: Int) {
                    handler.post { screenshotBusy = false }
                }
            }
        )
    }

    private data class Decision(val targetX: Float, val danger: Boolean)

    private fun analyze(src: Bitmap): Decision? {
        val w = src.width
        val h = src.height
        val y0 = (h * playTop).toInt().coerceAtLeast(0)
        val y1 = (h * playBottom).toInt().coerceAtMost(h - 1)
        if (y1 <= y0 + 40) return null

        // Detect the red/orange biohazard bucket using a downsampled mask.
        val step = 4
        val gridW = max(1, (w + step - 1) / step)
        val gridH = max(1, (y1 - y0 + step - 1) / step)
        val mask = ByteArray(gridW * gridH)
        for (gy in 0 until gridH) {
            val y = min(y1 - 1, y0 + gy * step)
            for (gx in 0 until gridW) {
                val x = min(w - 1, gx * step)
                val c = src.getPixel(x, y)
                val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                val red = r > 150 && r > g * 1.35 && r > b * 1.40 && g < 165
                mask[gy * gridW + gx] = if (red) 1 else 0
            }
        }

        val dangerBoxes = mutableListOf<Box>()
        val seen = BooleanArray(mask.size)
        for (gy in 0 until gridH) for (gx in 0 until gridW) {
            val idx = gy * gridW + gx
            if (mask[idx].toInt() == 0 || seen[idx]) continue
            val qx = IntArray(mask.size); val qy = IntArray(mask.size)
            var head = 0; var tail = 0
            qx[tail] = gx; qy[tail] = gy; tail++; seen[idx] = true
            var minX = gx; var maxX = gx; var minY = gy; var maxY = gy; var count = 0
            while (head < tail) {
                val x = qx[head]; val y = qy[head]; head++; count++
                minX = min(minX, x); maxX = max(maxX, x); minY = min(minY, y); maxY = max(maxY, y)
                val nx = intArrayOf(x - 1, x + 1, x, x)
                val ny = intArrayOf(y, y, y - 1, y + 1)
                for (k in 0..3) {
                    val xx = nx[k]; val yy = ny[k]
                    if (xx !in 0 until gridW || yy !in 0 until gridH) continue
                    val ni = yy * gridW + xx
                    if (mask[ni].toInt() == 1 && !seen[ni]) {
                        seen[ni] = true; qx[tail] = xx; qy[tail] = yy; tail++
                    }
                }
            }
            val bw = (maxX - minX + 1) * step
            val bh = (maxY - minY + 1) * step
            if (count >= 28 && bw >= w * 0.06f && bh >= h * 0.035f) {
                dangerBoxes += Box(minX * step, y0 + minY * step, maxX * step, y0 + maxY * step, count)
            }
        }

        val danger = dangerBoxes.maxByOrNull { it.area }
        if (danger != null) {
            val cx = (danger.left + danger.right) / 2f
            val target = if (cx < w / 2f) w * 0.80f else w * 0.20f
            return Decision(target, true)
        }

        // Soft collection target: colorful pixels in the lower/mid play field.
        val xBins = 14
        val scores = FloatArray(xBins)
        val yStart = (h * 0.42f).toInt().coerceAtLeast(y0)
        val yEnd = (h * 0.73f).toInt().coerceAtMost(y1)
        for (yy in yStart until yEnd step 6) {
            for (xx in 0 until w step 6) {
                val c = src.getPixel(xx, yy)
                val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                val hi = max(r, max(g, b)); val lo = min(r, min(g, b))
                val sat = hi - lo
                if (sat > 48 && hi < 245 && !(r > 145 && r > g * 1.35 && r > b * 1.40)) {
                    scores[min(xBins - 1, xx * xBins / w)] += 1f
                }
            }
        }
        var best = 0
        for (i in 1 until xBins) if (scores[i] > scores[best]) best = i
        if (scores[best] < 10f) return Decision(w / 2f, false)
        return Decision(((best + 0.5f) / xBins) * w, false)
    }

    private data class Box(val left: Int, val top: Int, val right: Int, val bottom: Int, val pixels: Int) {
        val area: Int get() = max(0, right - left) * max(0, bottom - top)
    }

    private fun applyDecision(decision: Decision) {
        val now = System.currentTimeMillis()
        if (now - lastSwipeAt < if (decision.danger) 240 else 380) return
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = resources.displayMetrics.heightPixels.toFloat()
        val target = decision.targetX.coerceIn(w * 0.10f, w * 0.90f)
        val start = if (lastTargetX >= 0f) lastTargetX else w / 2f
        if (abs(target - start) < w * 0.055f) return
        // Above the 3-button navigation bar; the game movement area is centered.
        val y = h * 0.58f
        swipe(start, y, target, y, if (decision.danger) 145L else 190L)
        lastTargetX = target
        lastSwipeAt = now
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun isLikelySystemPackage(pkg: String): Boolean {
        return pkg.startsWith("android") ||
                pkg.startsWith("com.android.settings") ||
                pkg.startsWith("com.google.android.permissioncontroller") ||
                pkg == "com.android.systemui" ||
                pkg == "com.google.android.gms"
    }
}
