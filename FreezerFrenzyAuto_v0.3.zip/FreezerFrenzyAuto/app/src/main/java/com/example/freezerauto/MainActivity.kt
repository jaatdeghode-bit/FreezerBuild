package com.example.freezerauto

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        val title = TextView(this).apply { text = "Freezer Auto v0.3"; textSize = 24f }
        val info = TextView(this).apply {
            text = "\n1. 3-button navigation is fine.\n" +
                    "2. Enable Accessibility Service.\n" +
                    "3. Open Freezer Frenzy.\n\n" +
                    "The bot steers around the red danger box and aims for non-danger items. " +
                    "It can return from a Play Store redirect. After a round, it can press a clearly labelled Next Round control. " +
                    "It does not press ad/watch/3x reward buttons."
            textSize = 16f
        }
        val settings = Button(this).apply {
            text = "Open Accessibility Settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(settings)
        setContentView(layout)
    }
}
