# Freezer Frenzy Auto v0.3

Android AccessibilityService prototype calibrated from the supplied gameplay recording and the supplied KEEP PLAYING screenshot.

## Current behavior
- Automatically learns the foreground game package.
- Uses Android Accessibility screenshots (Android 11+) for visual decisions.
- Detects the large red biohazard/danger obstacle and swipes away from it.
- When no danger is detected, biases movement toward colorful non-danger objects.
- Works with 3-button navigation because gestures are sent in the play area above the navigation bar.
- Detects a visible `Next Round` accessibility control and can press it after a round ends.
- If an advertisement redirects to Google Play, it only presses Back to return to the game.

## Important limitation
The service intentionally does NOT press `WATCH`, `3X`, or other ad/reward controls. Automating ad engagement can create artificial ad interactions. The bot is intended to automate gameplay and return from an accidental Play Store redirect, not generate ad revenue.

## Install/build
Open this folder in Android Studio, let Gradle sync, then build/install the debug APK.

After installing:
1. Open Freezer Auto.
2. Tap Open Accessibility Settings.
3. Enable Freezer Auto.
4. Open Freezer Frenzy.
5. Start a normal round manually once so the service learns the game package.

## Calibration
The red obstacle detector and play-area bounds are based on the supplied 20-second recording (576x1280) and the supplied post-collision screenshot. Different versions/aspect ratios may need threshold adjustment.
